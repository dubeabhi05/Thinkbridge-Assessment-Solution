1)Install or make sure Chrome version Version 92.0.4515.159 is installed on your system

2)Make sure java is installed in your system.

3)Download maven from "https://maven.apache.org/download.cgi" and set the environment variable "Maven_Home" 
  also copy the maven bin path into path location in environment variable

3)Locate and open 'Thinkbridge' project in Eclipse

4).Setting webdriver executable path"
 i)Copy Chrome driver location from chrome driver folder
 ii)open TestBase.java and update current chrome webdriver location in executable path.

5) Give SignUp and Email data in testdata.properties. Makesure Email and CreateEmail_mail should be same to check the inbox. 

6)Open command prompt navigate to project directory. 
	e.g cd C:\Users\adubey7\eclipse-workspace\FlightSerachTest

7)Enter below command : mvn clear
                        mvn compile
                        mvn test  (It will run both the tests)