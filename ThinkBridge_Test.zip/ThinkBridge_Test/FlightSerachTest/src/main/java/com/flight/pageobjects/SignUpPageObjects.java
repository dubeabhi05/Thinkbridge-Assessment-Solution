/**
 * 
 */
package com.flight.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author adubey7
 *
 */
public class SignUpPageObjects {
	
	WebDriver driver;
	
  public SignUpPageObjects(WebDriver sdriver)
    {
       this.driver=sdriver;
       PageFactory.initElements(driver, this);
    }

	
	@FindBy(how=How.CSS,using="#language > div.ui-select-match.ng-scope > span > span.ui-select-match-text.pull-left") WebElement dropdownlang;
	@FindBy(how=How.XPATH,using="//*[contains(@id,'ui-select-choices-row-1-')]//a//div") List<WebElement> dropdownlist;
	@FindBy(how=How.ID,using="name") WebElement fullName;
	@FindBy(how=How.ID,using="orgName") WebElement organizationname;
	@FindBy(how=How.ID,using="singUpEmail") WebElement signupemail;
	@FindBy(how=How.XPATH,using="//span[contains(text(),'I agree to the')]") WebElement agreetermscheckbox;
	@FindBy(how=How.XPATH,using="//button[contains(text(),'Get Started')]") WebElement getstartedbtn;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'A welcome email has been sent. Please check your e')]") WebElement alertemailsentmsg;
	
	
	public WebElement getDropDownLang() {
		return dropdownlang;
	}
	public List<WebElement> getDropDownLangList() {
		return dropdownlist;

	}
	
	public WebElement fullname() {
		return fullName;
	}
	public WebElement OrgName() {
		return organizationname;
	}
	public WebElement signUpEmail() {
		return signupemail;
	}
	public WebElement termCheckBox() {
		return agreetermscheckbox;
	}
	
	public WebElement getStartedBtn() {
		return getstartedbtn;
	}

}
