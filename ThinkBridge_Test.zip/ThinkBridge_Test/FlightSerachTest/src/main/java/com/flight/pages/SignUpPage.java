/**
 * 
 */
package com.flight.pages;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.flight.pageobjects.SignUpPageObjects;
import com.flight.utilities.WaitHelper;

/**
 * @author adubey7
 *
 */
public class SignUpPage {
	
	
	WebDriver driver;
	SignUpPageObjects signupobject;
	public static Properties testdata;
	public static FileInputStream fis;
	public WaitHelper wait;
	public SignUpPage(WebDriver driver)
	{
		this.driver= driver;
		
		signupobject = new SignUpPageObjects(driver);
	}
	
	public List<String> getDropDownList()
	{
		signupobject.getDropDownLang().click();
		
		List<String> actualList=new ArrayList<String>();
		List<WebElement> actualVal = signupobject.getDropDownLangList();
		
		for(WebElement ref : actualVal)
        {
            actualList.add(ref.getText());
        }
		
		return actualList;
	}
	
	public void signUp(String fullname,String orgname,String email) throws IOException
	{
		testdata=new Properties();
		fis=new FileInputStream("C:\\Users\\adubey7\\eclipse-workspace\\FlightSerachTest\\src\\test\\resources\\testdata\\testdata.properties");
		testdata.load(fis);
		fullname=testdata.getProperty("FullName");
		orgname=testdata.getProperty("OrganizationName");
		email=testdata.getProperty("Email");
		signupobject.fullname().sendKeys(fullname);
		signupobject.OrgName().sendKeys(orgname);
		signupobject.signUpEmail().sendKeys(email);
		signupobject.termCheckBox().click();
		signupobject.getStartedBtn().click();
		

   }    
	

}
